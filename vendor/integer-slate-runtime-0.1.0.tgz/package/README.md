# @integer/slate-runtime

The contract between everything: Slate edits these documents, Catalyst renders them,
slate-migrate produces them. HARD RULES: no imports from Catalyst internals; data access
only through `src/interfaces/data.ts`; unknown component types degrade gracefully.
Build order: schema → validator → registry → renderer → components (see /BUILD_SEQUENCE.md Phases 1–2).
