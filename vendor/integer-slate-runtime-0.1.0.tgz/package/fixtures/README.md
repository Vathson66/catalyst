# Fixtures

Every `*.json` file in this directory is run through `validatePageDocument` by
`test/fixtures.test.ts`. The **filename is the contract**:

- `invalid-*.json` — MUST fail validation, with an error message that names the real problem.
- everything else — MUST pass validation.

Adding a fixture requires no test changes. Adding an `invalid-*` fixture is the cheapest way to
pin down a validator guarantee you care about.

Documents here are plain schema-v1 JSON: no `$comment` keys, no extra metadata. The document
schema is `.strict()`, so a stray key fails the parse before the interesting check ever runs.

| Fixture | Expectation | What it pins down |
|---|---|---|
| `sample-page.json` | passes | The ordinary case: nested tree, token refs, a category content ref |
| `scheduled-page.json` | passes | `activeFrom` / `activeUntil` as ISO 8601 UTC (ADR 2 clock-based scheduling) |
| `unknown-component.json` | **passes** | An unknown node `type` is *valid JSON* — degradation is the renderer's job (schema §7.4), not the validator's. This fixture is also Phase 2's graceful-degradation render case. |
| `oversized-page.json` | passes | That a realistically huge page validates without choking. **Schema v1 sets no size limit and this fixture does not ask for one.** 326 nodes, max depth 26, ~330KB, ~40ms to validate. |
| `invalid-slug.json` | fails | Slug rules (schema §1): absolute, lowercase, no trailing slash |
| `invalid-token.json` | fails | The closed token vocabulary (schema §3) — `brand.tertiary` does not exist |
| `invalid-platform-key.json` | fails | The platform-agnostic linter (schema §5, ADR 5) — `bcId` is rejected even though the document is otherwise well-formed |

## On `oversized-page.json`

Generated rather than hand-written: 60 Prosoco-flavoured sections of mixed component types,
plus one deliberately deep branch of nested layout columns. It is regular schema-v1 JSON with
no special status — the only reason it is generated is that hand-authoring 326 nodes is
pointless. Edit it by hand or replace it wholesale; nothing depends on how it was produced.

Recursion is the real risk it guards: `nodeSchema` and both linter passes walk the tree, and
around 1600 levels of nesting overflows the stack. Real pages nest in the tens, so the fixture
tops out at 26 — deep enough to be meaningful, nowhere near the cliff.

## Still to add

- Per-component fixtures for the Phase 2 contract test suite (fixture → render → snapshot).
